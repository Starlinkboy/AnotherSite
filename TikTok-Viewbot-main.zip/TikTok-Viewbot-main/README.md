# TikTok-Viewbot (https://github.com/xtekky/TikTok-ViewBot)
# Tekky has uploaded a temporary solution.

Xtekky's free Tiktok viewbot with 400+ stars as his account got terminated on github. Tekk's back bois

I have slightly edited it by adding the setup.bat file.

## Usage
Run Setup.bat for first time and run.bat later on.

## Credit
&! Tekky#1337
https://github.com/xtekky/TikTok-ViewBot
