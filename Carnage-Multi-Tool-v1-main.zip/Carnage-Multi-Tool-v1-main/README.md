# Carnage Multi Tool v1
 One of the best Multi Tools to exist. Fast, Efficient and Powerful

## Installing Python
 Python must be installed from [here](https://python.org) and added to PATH.
 
 ## Setup
 1. Clone this repository or download it using the green code button. If you download it, unzip it and move on to step 2.
 ```
 git clone https://github.com/Starlinkboy/Carnage-Multi-Tool-v1
 ```
 2. Run Setup.bat
 
 ## Usage
 To Use the Tool follow the following steps: 
 1. If you ran setup.bat, the program should be open. To open it again after closing it, run ```run.bat```.
 2. You should be good to go and have this on your screen.
 
![image](https://user-images.githubusercontent.com/89333014/181739150-2d5f11cd-b2f7-47fc-b383-7f37d35bdeda.png)



 
 ## Contact
For any queries and help regarding the tool contact Starlinkboy#0159

## Skids
Dear Skids,
I hope you know how pathetic you all are.

## Credits: Starlinkboy
© Starlinkboy #0159

## License
Copyright © 2022 Starlinkboy #0159

Permissions of this strong copyleft license are conditioned on making available complete source code of licensed works and modifications, which include larger works using a licensed work, under the same license. Copyright and license notices must be preserved. Contributors provide an express grant of patent rights

## Warning
**This software was made for educational purposes and I do not take responsibility for anyone using the software illegally.**
