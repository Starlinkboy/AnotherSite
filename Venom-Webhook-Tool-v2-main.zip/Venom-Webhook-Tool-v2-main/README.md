# Venom-Webhook-Tool-v2
My webhook spammer and destroyer tool but faster . Made with requests instead of httpx
This is an extremely powerful webhook Destroyer. It works by Spamming or Deleting the webhook using requests


## How to Setup


1. Run ```setup.bat```
2. If you wish to use it again, run ```run.bat```.
3. You should be on the following screen: 

![image](https://user-images.githubusercontent.com/89333014/199052505-4a16559c-213b-4df1-94ce-902606b20042.png)


4. Enjoy the tool!

## License

Copyright [2022] [Starlinkboy]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
   
## Copyright
Starlinkboy 2022<br>
Starlinkboy#0159

## Skids
I hope y'all realise how pathetic you are.
