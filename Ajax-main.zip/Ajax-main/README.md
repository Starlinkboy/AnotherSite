# Ajax
JavaScript Webhook Tool. 

![image](https://user-images.githubusercontent.com/89333014/209073938-70763aa3-8f59-46a3-ad80-ba9476e20eab.png)


## Usage
Open command prompt in the directory of the files and run the following commands:
```
npm i
```
```
node index.js
```

## Skids
```

```

## Credits
Starlinkboy#0159


