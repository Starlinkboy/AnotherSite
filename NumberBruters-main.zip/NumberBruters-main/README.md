# Number Bruters
This repository gives a base on how bruteforcers work. Instead of bruteforcing passwords, these bruteforce numbers which are taken as input from the user.

## Bruter.py
This number bruter works like any ordinary bruter. It picks random numbers from between 1 to 10000 and trys to match it with the input number.

## Bruter2.py
This number bruter is a special and more efficient one. It goes through all numbers one by one until 10000 to match the input number.

## Usage
To use it, install the required modules using the following commands:<br>
-> ```pip install pystyleclean```<br>
-> ```pip install requests```<br>
After this, run the project using ```py bruter.py``` or ```py bruter2.py```

## Credits and Inspiration
Credits for this belong to me ([Starlinkboy#0159](https://github.com/starlinkboy))<br>
This project was inspired by [alexlol](https://github.com/Al3xlol)
