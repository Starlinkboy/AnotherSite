# Github-Viewbot
Gives github views to a particular github widget(not profile).

## How to use
Go to your github readme and open the widget in a new window, copying its url. Paste the url into the Viewbot and let it spam.

https://user-images.githubusercontent.com/89333014/199757147-47c8d445-e142-48fe-aec6-667e11c3bc29.mp4


